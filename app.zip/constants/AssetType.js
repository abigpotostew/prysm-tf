"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssetType = void 0;
var AssetType;
(function (AssetType) {
    AssetType[AssetType["erc20"] = 0] = "erc20";
})(AssetType = exports.AssetType || (exports.AssetType = {}));
//# sourceMappingURL=AssetType.js.map