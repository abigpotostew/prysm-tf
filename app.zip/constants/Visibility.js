"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Visibility = void 0;
var Visibility;
(function (Visibility) {
    Visibility[Visibility["public"] = 0] = "public";
    Visibility[Visibility["private"] = 1] = "private";
    Visibility[Visibility["archived"] = 2] = "archived";
})(Visibility = exports.Visibility || (exports.Visibility = {}));
//# sourceMappingURL=Visibility.js.map