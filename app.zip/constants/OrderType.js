"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderTypeDetails = exports.OrderType = void 0;
var OrderType;
(function (OrderType) {
    OrderType[OrderType["buy_market"] = 0] = "buy_market";
    OrderType[OrderType["sell_market"] = 1] = "sell_market";
    OrderType[OrderType["buy_limit"] = 2] = "buy_limit";
    OrderType[OrderType["sell_limit"] = 3] = "sell_limit";
})(OrderType = exports.OrderType || (exports.OrderType = {}));
exports.OrderTypeDetails = {
    [OrderType.buy_market]: { type: 'buy', action: 'market' },
    [OrderType.sell_market]: { type: 'sell', action: 'market' },
    [OrderType.buy_limit]: { type: 'buy', action: 'limit' },
    [OrderType.sell_limit]: { type: 'sell', action: 'limit' }
};
//# sourceMappingURL=OrderType.js.map