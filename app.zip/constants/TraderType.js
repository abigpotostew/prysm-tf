"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TraderType = void 0;
var TraderType;
(function (TraderType) {
    TraderType[TraderType["lurker"] = 0] = "lurker";
    TraderType[TraderType["trader"] = 1] = "trader";
    TraderType[TraderType["creator"] = 2] = "creator";
})(TraderType = exports.TraderType || (exports.TraderType = {}));
//# sourceMappingURL=TraderType.js.map