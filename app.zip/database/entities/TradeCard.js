"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TradeCard = void 0;
const typeorm_1 = require("typeorm");
const User_1 = require("./User");
const LikedTrade_1 = require("./LikedTrade");
const IdeaComment_1 = require("./IdeaComment");
const OrderType_1 = require("../../constants/OrderType");
const Visibility_1 = require("../../constants/Visibility");
const Asset_1 = require("./Asset");
let TradeCard = class TradeCard {
};
__decorate([
    typeorm_1.PrimaryGeneratedColumn('uuid'),
    __metadata("design:type", String)
], TradeCard.prototype, "id", void 0);
__decorate([
    typeorm_1.Column('timestamptz', { default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], TradeCard.prototype, "time", void 0);
__decorate([
    typeorm_1.Column('timestamptz', { name: 'last_executed', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], TradeCard.prototype, "lastExecuted", void 0);
__decorate([
    typeorm_1.Column({ name: 'order_type', type: 'enum', enum: OrderType_1.OrderType }),
    __metadata("design:type", Number)
], TradeCard.prototype, "orderType", void 0);
__decorate([
    typeorm_1.Column({ name: 'expiry_time', nullable: true }),
    __metadata("design:type", Number)
], TradeCard.prototype, "expiryTime", void 0);
__decorate([
    typeorm_1.Column('real', { name: 'market_price' }),
    __metadata("design:type", Number)
], TradeCard.prototype, "marketPrice", void 0);
__decorate([
    typeorm_1.Column('real', { name: 'limit_price', nullable: true }),
    __metadata("design:type", Number)
], TradeCard.prototype, "limitPrice", void 0);
__decorate([
    typeorm_1.Column('real', { name: 'take_profit_price', nullable: true }),
    __metadata("design:type", Number)
], TradeCard.prototype, "takeProfitPrice", void 0);
__decorate([
    typeorm_1.Column(),
    __metadata("design:type", String)
], TradeCard.prototype, "title", void 0);
__decorate([
    typeorm_1.Column({ nullable: true }),
    __metadata("design:type", String)
], TradeCard.prototype, "description", void 0);
__decorate([
    typeorm_1.Column({ name: 'num_likes', default: 0 }),
    __metadata("design:type", Number)
], TradeCard.prototype, "numLikes", void 0);
__decorate([
    typeorm_1.Column('varchar', { nullable: true }),
    __metadata("design:type", Array)
], TradeCard.prototype, "tags", void 0);
__decorate([
    typeorm_1.Column({ name: 'num_executed', default: 0 }),
    __metadata("design:type", Number)
], TradeCard.prototype, "numExecuted", void 0);
__decorate([
    typeorm_1.Column({ name: 'num_reviewed', default: 0 }),
    __metadata("design:type", Number)
], TradeCard.prototype, "numReviewed", void 0);
__decorate([
    typeorm_1.Column({ default: 0 }),
    __metadata("design:type", Number)
], TradeCard.prototype, "views", void 0);
__decorate([
    typeorm_1.Column({ name: 'tx_hash', nullable: true }),
    __metadata("design:type", String)
], TradeCard.prototype, "txHash", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: 'related_trades', nullable: true }),
    __metadata("design:type", Array)
], TradeCard.prototype, "relatedTrades", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: 'related_content', nullable: true }),
    __metadata("design:type", Array)
], TradeCard.prototype, "relatedContent", void 0);
__decorate([
    typeorm_1.Column({ name: 'self_executed', default: false }),
    __metadata("design:type", Boolean)
], TradeCard.prototype, "selfExecuted", void 0);
__decorate([
    typeorm_1.Column({ type: 'enum', enum: Visibility_1.Visibility, default: Visibility_1.Visibility.public }),
    __metadata("design:type", Number)
], TradeCard.prototype, "visibility", void 0);
__decorate([
    typeorm_1.Column('real', { name: 'stop_loss', nullable: true }),
    __metadata("design:type", Number)
], TradeCard.prototype, "stopLoss", void 0);
__decorate([
    typeorm_1.ManyToOne(() => User_1.User),
    typeorm_1.JoinColumn({ name: 'user_id' }),
    __metadata("design:type", User_1.User)
], TradeCard.prototype, "user", void 0);
__decorate([
    typeorm_1.ManyToOne(() => Asset_1.Asset),
    typeorm_1.JoinColumn({ name: 'pay_with_asset_id' }),
    __metadata("design:type", Asset_1.Asset)
], TradeCard.prototype, "payWithAsset", void 0);
__decorate([
    typeorm_1.ManyToOne(() => Asset_1.Asset),
    typeorm_1.JoinColumn({ name: 'receive_asset_id' }),
    __metadata("design:type", Asset_1.Asset)
], TradeCard.prototype, "receiveAsset", void 0);
__decorate([
    typeorm_1.OneToMany(() => LikedTrade_1.LikedTrade, (like) => like.tradeCard),
    __metadata("design:type", Array)
], TradeCard.prototype, "likes", void 0);
__decorate([
    typeorm_1.OneToMany(() => IdeaComment_1.IdeaComment, (comment) => comment.tradeCard),
    __metadata("design:type", Array)
], TradeCard.prototype, "comments", void 0);
TradeCard = __decorate([
    typeorm_1.Entity('trade_cards')
], TradeCard);
exports.TradeCard = TradeCard;
//# sourceMappingURL=TradeCard.js.map