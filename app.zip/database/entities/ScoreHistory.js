"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScoreHistory = void 0;
const typeorm_1 = require("typeorm");
const User_1 = require("./User");
const ScoreEvent_1 = require("./ScoreEvent");
let ScoreHistory = class ScoreHistory {
};
__decorate([
    typeorm_1.PrimaryGeneratedColumn('uuid'),
    __metadata("design:type", String)
], ScoreHistory.prototype, "id", void 0);
__decorate([
    typeorm_1.Column('timestamptz', { default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], ScoreHistory.prototype, "time", void 0);
__decorate([
    typeorm_1.Column({ name: 'current_score' }),
    __metadata("design:type", Number)
], ScoreHistory.prototype, "currentScore", void 0);
__decorate([
    typeorm_1.Column({ name: 'prev_score' }),
    __metadata("design:type", Number)
], ScoreHistory.prototype, "prevScore", void 0);
__decorate([
    typeorm_1.ManyToOne(() => User_1.User),
    typeorm_1.JoinColumn({ name: 'user_id' }),
    __metadata("design:type", User_1.User)
], ScoreHistory.prototype, "user", void 0);
__decorate([
    typeorm_1.ManyToOne(() => ScoreEvent_1.ScoreEvent),
    typeorm_1.JoinColumn({ name: 'score_event_id' }),
    __metadata("design:type", ScoreEvent_1.ScoreEvent)
], ScoreHistory.prototype, "scoreEvent", void 0);
ScoreHistory = __decorate([
    typeorm_1.Entity('score_history')
], ScoreHistory);
exports.ScoreHistory = ScoreHistory;
//# sourceMappingURL=ScoreHistory.js.map