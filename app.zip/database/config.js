"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dbConnection = void 0;
const env = process.env.NODE_ENV || 'development';
const dbConnection = {
    type: 'postgres',
    host: process.env.POSTGRESQL_HOST,
    port: Number(process.env.POSTGRESQL_PORT),
    username: process.env.POSTGRESQL_USERNAME,
    password: process.env.POSTGRESQL_PASSWORD,
    database: process.env.POSTGRESQL_DATABASE,
    synchronize: true,
    logging: false,
    entities: [
        env === 'production' ? 'dist/database/entities/*{.ts,.js}' : 'src/database/entities/*{.ts,.js}',
    ],
    migrations: [
        env === 'production'
            ? 'dist/database/migrations/*{.ts,.js}'
            : 'src/database/migrations/*{.ts,.js}',
    ],
    subscribers: [
        env === 'production'
            ? 'dist/database/subscribers/*{.ts,.js}'
            : 'src/database/subscribers/*{.ts,.js}',
    ],
    cli: {
        entitiesDir: 'src/database/entities',
        migrationsDir: 'src/database/migrations',
        subscribersDir: 'src/database/subscribers',
    },
};
exports.dbConnection = dbConnection;
//# sourceMappingURL=config.js.map