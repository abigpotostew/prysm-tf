"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddAssetData1612721396846 = void 0;
const asset_data_json_1 = __importDefault(require("../../constants/asset-data.json"));
class AddAssetData1612721396846 {
    constructor() {
        this.name = 'AddAssetData1612721396846';
    }
    async up(queryRunner) {
        for (const info of asset_data_json_1.default) {
            const logoThumb = info.logoURI;
            const logoSmall = logoThumb === null || logoThumb === void 0 ? void 0 : logoThumb.replace('/thumb/', '/small/');
            const logoMedium = logoThumb === null || logoThumb === void 0 ? void 0 : logoThumb.replace('/thumb/', '/large/');
            await queryRunner.query(`INSERT INTO asset_list (chain_id, address, name, symbol, decimals, logo_thumb, logo_small, logo_medium, list_source, asset_type)
        VALUES ('${info.chainId}', '${info.address}', '${info.name}', '${info.symbol}', '${info.decimals}', '${logoThumb}', '${logoSmall}', '${logoMedium}', 'https://tokens.coingecko.com/uniswap/all.json', '0')`);
        }
    }
    async down(queryRunner) {
        await queryRunner.query(`DELETE FROM asset_list`);
    }
}
exports.AddAssetData1612721396846 = AddAssetData1612721396846;
//# sourceMappingURL=1612726322036-AddAssetData.js.map