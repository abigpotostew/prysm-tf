"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddScoreEvents1613416146936 = void 0;
class AddScoreEvents1613416146936 {
    constructor() {
        this.name = 'AddScoreEvents1613416146936';
    }
    async up(queryRunner) {
        await queryRunner.query(`INSERT INTO score_events (name, description, points)
      VALUES ('first_idea_created', 'When a user creates a trade idea for the first time', 100)`);
    }
    async down(queryRunner) {
        await queryRunner.query(`DELETE FROM score_events`);
    }
}
exports.AddScoreEvents1613416146936 = AddScoreEvents1613416146936;
//# sourceMappingURL=1613416146936-AddScoreEvents.js.map