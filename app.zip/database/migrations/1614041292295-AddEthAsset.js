"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddEthAsset1614041292295 = void 0;
class AddEthAsset1614041292295 {
    constructor() {
        this.name = 'AddEthAsset1614041292295';
    }
    async up(queryRunner) {
        await queryRunner.query(`INSERT INTO asset_list (chain_id, address, name, symbol, decimals, logo_thumb, logo_small, logo_medium, list_source, asset_type)
    VALUES ('1', '0x0', 'Ethereum', 'ETH', '18', 'https://logos.covalenthq.com/tokens/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2.png', 'https://logos.covalenthq.com/tokens/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2.png', 'https://logos.covalenthq.com/tokens/0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2.png', 'https://tokens.coingecko.com/uniswap/all.json', '0')`);
    }
    async down(queryRunner) {
        await queryRunner.query(`DELETE FROM asset_list WHERE symbol = 'ETH'`);
    }
}
exports.AddEthAsset1614041292295 = AddEthAsset1614041292295;
//# sourceMappingURL=1614041292295-AddEthAsset.js.map