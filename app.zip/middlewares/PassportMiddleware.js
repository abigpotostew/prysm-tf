"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.passportInitialize = void 0;
const passport_1 = __importDefault(require("passport"));
const passport_jwt_1 = __importDefault(require("passport-jwt"));
const typeorm_1 = require("typeorm");
const User_1 = require("../database/entities/User");
const passportInitialize = (app) => {
    passport_1.default.use('jwt-header', new passport_jwt_1.default.Strategy({
        jwtFromRequest: passport_jwt_1.default.ExtractJwt.fromAuthHeaderAsBearerToken(),
        secretOrKey: process.env.JWT_SECRET,
    }, async (payload, done) => {
        try {
            const user = await typeorm_1.getManager().findOne(User_1.User, payload.id);
            done(undefined, user, payload);
        }
        catch (error) {
            done(error, false);
        }
    }));
    passport_1.default.serializeUser((user, done) => {
        done(null, user);
    });
    passport_1.default.deserializeUser((user, done) => {
        done(null, user);
    });
    app.use(passport_1.default.initialize());
    app.use(passport_1.default.session());
};
exports.passportInitialize = passportInitialize;
//# sourceMappingURL=PassportMiddleware.js.map