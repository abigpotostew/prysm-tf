"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = __importDefault(require("joi"));
const pick_1 = __importDefault(require("lodash/pick"));
const TraderType_1 = require("../../constants/TraderType");
class UserValidator {
    async userProfile(req, res, next) {
        const reqData = pick_1.default(req.params, ['id']);
        const schema = joi_1.default.object({
            id: joi_1.default.string().required().label('id'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(422).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async getTopUsers(req, res, next) {
        const reqData = pick_1.default(req.query, ['pageNumber', 'pageSize']);
        const schema = joi_1.default.object({
            pageNumber: joi_1.default.number().label('pageNumber'),
            pageSize: joi_1.default.number().label('pageSize'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(422).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async setTraderType(req, res, next) {
        const reqData = pick_1.default(req.body, ['userType']);
        const schema = joi_1.default.object({
            userType: joi_1.default.number()
                .valid(TraderType_1.TraderType.lurker, TraderType_1.TraderType.trader, TraderType_1.TraderType.creator)
                .required()
                .label('userType'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
}
exports.default = new UserValidator();
//# sourceMappingURL=UserValidator.js.map