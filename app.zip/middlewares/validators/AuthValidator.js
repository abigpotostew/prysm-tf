"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = __importDefault(require("joi"));
const pick_1 = __importDefault(require("lodash/pick"));
class AuthValidator {
    async login(req, res, next) {
        const reqData = pick_1.default(req.body, ['address', 'signature', 'token']);
        const schema = joi_1.default.object({
            address: joi_1.default.string().required().label('address'),
            signature: joi_1.default.string().required().label('signature'),
            token: joi_1.default.string().required().label('token'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(422).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
}
exports.default = new AuthValidator();
//# sourceMappingURL=AuthValidator.js.map