"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const joi_1 = __importDefault(require("joi"));
const pick_1 = __importDefault(require("lodash/pick"));
const OrderType_1 = require("../../constants/OrderType");
const Visibility_1 = require("../../constants/Visibility");
class TradeIdeaValidator {
    async getAll(req, res, next) {
        const reqData = pick_1.default(req.query, ['pageNumber', 'pageSize', 'filter']);
        const schema = joi_1.default.object({
            pageNumber: joi_1.default.number().label('pageNumber'),
            pageSize: joi_1.default.number().label('pageSize'),
            sort: joi_1.default.string().valid('date', 'popular').label('sort'),
            uid: joi_1.default.string().label('uid'),
            filter: joi_1.default.string().label('filter'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(422).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async get(req, res, next) {
        const reqData = pick_1.default(req.params, ['id']);
        const schema = joi_1.default.object({
            id: joi_1.default.string().required().label('id'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(422).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async create(req, res, next) {
        const reqData = pick_1.default(req.body, [
            'expiryTime',
            'marketPrice',
            'payWithAssetId',
            'receiveAssetId',
            'relatedTrades',
            'relatedContent',
            'orderType',
            'limitPrice',
            'takeProfitPrice',
            'title',
            'description',
            'tags',
            'stopLoss',
        ]);
        const schema = joi_1.default.object({
            expiryTime: joi_1.default.number().label('expiryTime'),
            marketPrice: joi_1.default.number().required().label('marketPrice'),
            payWithAssetId: joi_1.default.string().label('payWithAssetId'),
            receiveAssetId: joi_1.default.string().required().label('receiveAssetId'),
            relatedTrades: joi_1.default.array().items(joi_1.default.string()).label('relatedTrades'),
            relatedContent: joi_1.default.array().items(joi_1.default.string()).label('relatedTrades'),
            orderType: joi_1.default.number()
                .valid(OrderType_1.OrderType.buy_market, OrderType_1.OrderType.sell_market, OrderType_1.OrderType.buy_limit, OrderType_1.OrderType.sell_limit)
                .required()
                .label('orderType'),
            limitPrice: joi_1.default.number()
                .greater(0)
                .when('orderType', {
                is: joi_1.default.valid(OrderType_1.OrderType.buy_limit, OrderType_1.OrderType.sell_limit),
                then: joi_1.default.required(),
            })
                .label('limitPrice'),
            takeProfitPrice: joi_1.default.number().greater(0).label('takeProfitPrice'),
            title: joi_1.default.string().required().label('title'),
            description: joi_1.default.string().allow('').label('description'),
            tags: joi_1.default.array().items(joi_1.default.string()).label('tags'),
            stopLoss: joi_1.default.number().label('stopLoss'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async setArchive(req, res, next) {
        const reqData1 = pick_1.default(req.params, ['id']);
        const reqData2 = pick_1.default(req.body, ['visibility']);
        const schema = joi_1.default.object({
            id: joi_1.default.string().required().label('id'),
            visibility: joi_1.default.number()
                .valid(Visibility_1.Visibility.public, Visibility_1.Visibility.private, Visibility_1.Visibility.archived)
                .required()
                .label('visibility'),
        });
        const { value, error } = schema.validate({ ...reqData1, ...reqData2 });
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async setLike(req, res, next) {
        const reqData = pick_1.default(req.body, ['id']);
        const schema = joi_1.default.object({
            id: joi_1.default.string().required().label('id'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async addComment(req, res, next) {
        const reqData = pick_1.default(req.body, ['tradeCardId', 'content']);
        const schema = joi_1.default.object({
            tradeCardId: joi_1.default.string().required().label('tradeCardId'),
            content: joi_1.default.string().required().label('content'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
    async addScore(req, res, next) {
        const reqData = pick_1.default(req.params, ['id']);
        const schema = joi_1.default.object({
            id: joi_1.default.string().required().label('id'),
        });
        const { value, error } = schema.validate(reqData);
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        req.reqData = value;
        return next();
    }
}
exports.default = new TradeIdeaValidator();
//# sourceMappingURL=TradeIdeaValidator.js.map