"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const jwt = __importStar(require("jsonwebtoken"));
const web3_1 = __importDefault(require("web3"));
const TraderAddress_1 = require("../database/entities/TraderAddress");
const User_1 = require("../database/entities/User");
const web3 = new web3_1.default(web3_1.default.givenProvider || 'ws://localhost:8546');
class AuthController {
    async login(req, res) {
        try {
            const { address, token, signature } = req.body;
            const account = web3.utils.toChecksumAddress(address);
            const signedMessage = `Prysm One-Time Key : ${token}`;
            const recoverAddress = web3.eth.accounts.recover(signedMessage, signature);
            if (account !== recoverAddress) {
                console.log('NO', account, recoverAddress);
                return res.status(400).json({ message: 'Login unsuccessful.' });
            }
            let traderAddress = await typeorm_1.getManager().findOne(TraderAddress_1.TraderAddress, {
                where: { address: account },
                relations: ['user'],
            });
            if (!traderAddress) {
                const user = new User_1.User();
                user.userName = account;
                await typeorm_1.getManager().save(user);
                traderAddress = new TraderAddress_1.TraderAddress();
                traderAddress.user = user;
                traderAddress.address = account;
                await typeorm_1.getManager().save(traderAddress);
            }
            const id = traderAddress === null || traderAddress === void 0 ? void 0 : traderAddress.user.id;
            const jwtToken = jwt.sign({ id }, process.env.JWT_SECRET || '');
            return res.status(200).json({ token: jwtToken });
        }
        catch (e) {
            console.log(e);
            return res.status(400).json({ message: 'Login unsuccessful.' });
        }
    }
}
exports.default = new AuthController();
//# sourceMappingURL=AuthController.js.map