"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const OrderType_1 = require("../constants/OrderType");
const Asset_1 = require("../database/entities/Asset");
const TradeCard_1 = require("../database/entities/TradeCard");
const LikedTrade_1 = require("../database/entities/LikedTrade");
const IdeaComment_1 = require("../database/entities/IdeaComment");
const ScoreEvent_1 = require("../database/entities/ScoreEvent");
const ScoreHistory_1 = require("../database/entities/ScoreHistory");
class TradeIdeaController {
    async getAll(req, res) {
        try {
            const user = req.user;
            const { pageNumber = 0, pageSize = 0, sort, uid, filter } = req.query;
            const take = Number(pageSize);
            const skip = Number(pageNumber) * take;
            const options = {
                relations: ['user', 'payWithAsset', 'receiveAsset', 'likes', 'likes.user', 'comments'],
                where: {},
                skip,
                take,
                order: {
                    time: 'DESC',
                }
            };
            if (sort === 'popular') {
                options.order = {
                    numLikes: 'DESC',
                };
            }
            let uidWhere;
            if (uid) {
                uidWhere = {
                    user: {
                        id: uid
                    }
                };
            }
            let filterWere;
            if (filter) {
                const ids = filter.split(',');
                filterWere = {
                    receiveAsset: {
                        id: typeorm_1.In(ids),
                    }
                };
            }
            if (uid || filter) {
                options.where = {
                    ...uidWhere,
                    ...filterWere
                };
            }
            const [tradeCards, count] = await typeorm_1.getManager().findAndCount(TradeCard_1.TradeCard, options);
            const data = tradeCards.map((card) => ({
                tradeCardId: card.id,
                title: card.title,
                time: card.time,
                likes: card.likes.length,
                isLiked: !!card.likes.find(item => item.user.id === user.id),
                numComments: card.comments.length,
                numExecuted: card.numExecuted,
                txHash: card.txHash,
                selfExecuted: card.selfExecuted,
                tags: card.tags,
                views: card.views,
                creatorDetails: {
                    uid: card.user.id,
                    userName: card.user.userName,
                    userLogo: card.user.userLogo,
                    followers: card.user.followers,
                    score: card.user.score,
                },
                assetDetails: {
                    to: {
                        marketPrice: card.marketPrice,
                        id: card.receiveAsset.id,
                        symbol: card.receiveAsset.symbol,
                        name: card.receiveAsset.name,
                        address: card.receiveAsset.address,
                        logo: card.receiveAsset.logoThumb,
                    },
                },
                ideaDetails: {
                    orderType: OrderType_1.OrderTypeDetails[card.orderType].type,
                    orderAction: OrderType_1.OrderTypeDetails[card.orderType].action,
                    ...card.orderType === OrderType_1.OrderType.buy_limit || card.orderType === OrderType_1.OrderType.sell_limit ? { limitPrice: card.limitPrice } : {},
                    takeProfit: card.takeProfitPrice,
                    stopLoss: card.stopLoss,
                }
            }));
            const moreData = !!take && count > skip + take;
            return res.status(200).json({ data, moreData });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async get(req, res) {
        const user = req.user;
        const { id } = req.params;
        try {
            const card = await typeorm_1.getManager().findOne(TradeCard_1.TradeCard, {
                relations: ['user', 'payWithAsset', 'receiveAsset', 'likes', 'likes.user', 'comments'],
                where: { id }
            });
            if (!card) {
                return res.status(400).json({ message: 'Invalid id' });
            }
            const data = {
                tradeCardId: card.id,
                title: card.title,
                description: card.description,
                time: card.time,
                likes: card.likes.length,
                isLiked: !!card.likes.find(item => item.user.id === user.id),
                numComments: card.comments.length,
                numExecuted: card.numExecuted,
                txHash: card.txHash,
                selfExecuted: card.selfExecuted,
                tags: card.tags,
                views: card.views,
                creatorDetails: {
                    uid: card.user.id,
                    userName: card.user.userName,
                    userLogo: card.user.userLogo,
                    followers: card.user.followers,
                    score: card.user.score,
                },
                assetDetails: {
                    to: {
                        marketPrice: card.marketPrice,
                        id: card.receiveAsset.id,
                        symbol: card.receiveAsset.symbol,
                        name: card.receiveAsset.name,
                        address: card.receiveAsset.address,
                        logo: card.receiveAsset.logoThumb,
                    },
                },
                ideaDetails: {
                    orderType: OrderType_1.OrderTypeDetails[card.orderType].type,
                    orderAction: OrderType_1.OrderTypeDetails[card.orderType].action,
                    ...card.orderType === OrderType_1.OrderType.buy_limit || card.orderType === OrderType_1.OrderType.sell_limit ? { limitPrice: card.limitPrice } : {},
                    takeProfit: card.takeProfitPrice,
                    stopLoss: card.stopLoss,
                }
            };
            return res.status(200).json({ data });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async create(req, res) {
        try {
            const { expiryTime, marketPrice, payWithAssetId, receiveAssetId, relatedTrades, relatedContent, orderType, limitPrice, takeProfitPrice, title, description, tags, stopLoss } = req.body;
            let payWithAsset;
            if (payWithAssetId) {
                payWithAsset = await typeorm_1.getManager().findOne(Asset_1.Asset, payWithAssetId);
                if (!payWithAsset) {
                    return res.status(400).json({ message: 'Invalid payWithAssetId.' });
                }
            }
            const receiveAsset = await typeorm_1.getManager().findOne(Asset_1.Asset, receiveAssetId);
            if (!receiveAsset) {
                return res.status(400).json({ message: 'Invalid receiveAssetId.' });
            }
            const tradeCard = new TradeCard_1.TradeCard();
            tradeCard.user = req.user;
            tradeCard.expiryTime = expiryTime;
            tradeCard.marketPrice = marketPrice;
            if (payWithAsset) {
                tradeCard.payWithAsset = payWithAsset;
            }
            tradeCard.receiveAsset = receiveAsset;
            tradeCard.relatedTrades = relatedTrades;
            tradeCard.relatedContent = relatedContent;
            tradeCard.orderType = orderType;
            tradeCard.limitPrice = limitPrice;
            tradeCard.takeProfitPrice = takeProfitPrice;
            tradeCard.title = title;
            tradeCard.description = description;
            tradeCard.tags = tags;
            tradeCard.stopLoss = stopLoss;
            await typeorm_1.getManager().save(tradeCard);
            return res.status(200).json({
                message: 'success.',
                tradeCardId: tradeCard.id,
            });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async setArchive(req, res) {
        try {
            const { id } = req.params;
            const { visibility } = req.body;
            const card = await typeorm_1.getManager().findOne(TradeCard_1.TradeCard, id);
            if (!card) {
                return res.status(400).json({ message: 'Invalid id' });
            }
            card.visibility = visibility;
            typeorm_1.getManager().save(card);
            return res.status(200).json({
                message: 'success.'
            });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async setLike(req, res) {
        try {
            const { id } = req.body;
            const user = req.user;
            const tradeCard = await typeorm_1.getManager().findOne(TradeCard_1.TradeCard, {
                where: { id },
                relations: ['user'],
            });
            if (!tradeCard) {
                return res.status(400).json({ message: 'Invalid ID.' });
            }
            if (tradeCard.user.id === user.id) {
                return res.status(400).json({ message: 'You cannot "like" your own ideas.' });
            }
            let status;
            let likedTrade = await typeorm_1.getManager().findOne(LikedTrade_1.LikedTrade, {
                relations: ['tradeCard', 'user'],
                where: {
                    tradeCard: { id },
                    user: { id: user.id }
                },
            });
            if (likedTrade) {
                await typeorm_1.getManager().remove(likedTrade);
                status = 'Unlike';
            }
            else {
                likedTrade = new LikedTrade_1.LikedTrade();
                likedTrade.user = user;
                likedTrade.tradeCard = tradeCard;
                await typeorm_1.getManager().save(likedTrade);
                status = 'Like';
            }
            const [_, numLikes] = await typeorm_1.getManager().findAndCount(LikedTrade_1.LikedTrade, {
                relations: ['tradeCard'],
                where: {
                    tradeCard: { id },
                },
            });
            tradeCard.numLikes = numLikes;
            await typeorm_1.getManager().save(tradeCard);
            return res.status(200).json({
                message: 'success.',
                status
            });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async addComment(req, res) {
        try {
            const { tradeCardId, content } = req.body;
            const user = req.user;
            const tradeCard = await typeorm_1.getManager().findOne(TradeCard_1.TradeCard, {
                where: { id: tradeCardId, },
                relations: ['user'],
            });
            if (!tradeCard) {
                return res.status(400).json({ message: 'Invalid tradeCardId.' });
            }
            const ideaComment = new IdeaComment_1.IdeaComment();
            ideaComment.user = user;
            ideaComment.tradeCard = tradeCard;
            ideaComment.content = content;
            await typeorm_1.getManager().save(ideaComment);
            return res.status(200).json({});
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async addScore(req, res) {
        try {
            const { id } = req.params;
            const user = req.user;
            const scoreEvent = await typeorm_1.getManager().findOne(ScoreEvent_1.ScoreEvent, id);
            if (!scoreEvent) {
                return res.status(400).json({ message: 'Invalid scoreEventID.' });
            }
            const scoreHistory = new ScoreHistory_1.ScoreHistory();
            scoreHistory.scoreEvent = scoreEvent;
            scoreHistory.prevScore = user.score;
            scoreHistory.currentScore = user.score + scoreEvent.points;
            await typeorm_1.getManager().save(scoreHistory);
            user.score = scoreHistory.currentScore;
            await typeorm_1.getManager().save(user);
            return res.status(200).json({});
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
}
exports.default = new TradeIdeaController();
//# sourceMappingURL=TradeIdeaController.js.map