"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const Asset_1 = require("../database/entities/Asset");
class AssetListController {
    async getAll(req, res) {
        try {
            const assets = await typeorm_1.getManager().find(Asset_1.Asset, {
                where: {
                    active: true,
                },
            });
            const tokenlist = assets.map((item) => ({
                assetId: item.id,
                chainId: item.chainId,
                address: item.address,
                name: item.name,
                symbol: item.symbol,
                decimals: item.decimals,
                marketcapRank: item.marketcapRank,
                assetType: item.assetType,
                logoMedium: item.logoMedium,
                tags: item.tags,
                time: item.time
            }));
            return res.status(200).json({ tokenlist });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
}
exports.default = new AssetListController();
//# sourceMappingURL=AssetListController.js.map