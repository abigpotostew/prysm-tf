"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const ScoreEvent_1 = require("../database/entities/ScoreEvent");
class ScoreEventsController {
    async getAll(req, res) {
        try {
            const assets = await typeorm_1.getManager().find(ScoreEvent_1.ScoreEvent);
            const scoreEvents = assets.map((item) => ({
                scoreEventsId: item.id,
                name: item.name,
                description: item.description,
                points: item.points,
            }));
            return res.status(200).json({ scoreEvents });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
}
exports.default = new ScoreEventsController();
//# sourceMappingURL=ScoreEventsController.js.map