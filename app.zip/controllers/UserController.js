"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const User_1 = require("../database/entities/User");
class UserController {
    async myProfile(req, res) {
        try {
            const { id } = req.user;
            const user = await typeorm_1.getManager().findOne(User_1.User, {
                relations: ['traderAddresses'],
                where: { id },
            });
            return res.status(200).json(user);
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async userProfile(req, res) {
        try {
            const { id } = req.params;
            const user = await typeorm_1.getManager().findOne(User_1.User, {
                relations: ['traderAddresses'],
                where: { id },
            });
            return res.status(200).json(user);
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async setTraderType(req, res) {
        try {
            const { userType } = req.body;
            const user = req.user;
            user.traderType = userType;
            await typeorm_1.getManager().save(user);
            return res.status(200).json({});
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
    async getTopUsers(req, res) {
        try {
            const { pageNumber = 0, pageSize = 0 } = req.query;
            const take = Number(pageSize);
            const skip = Number(pageNumber) * take;
            const options = {
                skip,
                take,
                order: {
                    score: 'DESC',
                },
            };
            const [data, count] = await typeorm_1.getManager().findAndCount(User_1.User, options);
            const moreData = !take || count > skip + take;
            return res.status(200).json({ data, moreData });
        }
        catch (e) {
            console.log(e);
            return res.status(500).json({ message: 'Internal error' });
        }
    }
}
exports.default = new UserController();
//# sourceMappingURL=UserController.js.map