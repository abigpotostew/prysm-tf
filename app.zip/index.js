"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const dotenv_1 = __importDefault(require("dotenv"));
const body_parser_1 = __importDefault(require("body-parser"));
const cors_1 = __importDefault(require("cors"));
const express_1 = __importDefault(require("express"));
dotenv_1.default.config();
const typeorm_1 = require("typeorm");
const PassportMiddleware_1 = require("./middlewares/PassportMiddleware");
const routes_1 = __importDefault(require("./routes"));
const config_1 = require("./database/config");
const app = express_1.default();
app.use(cors_1.default());
app.use(body_parser_1.default.json());
app.use(body_parser_1.default.urlencoded({ extended: false }));
PassportMiddleware_1.passportInitialize(app);
app.use(routes_1.default);
const startServer = async () => {
    try {
        await typeorm_1.createConnection(config_1.dbConnection);
    }
    catch (error) {
        console.log(error.message);
        process.exit(1);
    }
    const port = process.env.PORT || 3000;
    app.listen(port, () => {
        console.log(`🚀 App listening on the port ${port}`);
    });
};
startServer();
//# sourceMappingURL=index.js.map